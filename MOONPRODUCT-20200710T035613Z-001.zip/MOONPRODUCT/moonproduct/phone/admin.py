from django.contrib import admin
from phone.models import Contact , Detaile

# Register your models here.
admin.site.register(Contact)
admin.site.register(Detaile)
